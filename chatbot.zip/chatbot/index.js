document.addEventListener("DOMContentLoaded", function() {
    const openButton = document.querySelector(".chatbot_icon"); //The chatbot icon is saved as a button
    const botContent = document.querySelector(".disclaimer"); //The iframe where the chatbot is contained
    const openDisclaimer = document.getElementById("toggleButton"); 
    const textContent = document.querySelector(".disclaimerText");
    openButton.addEventListener("click",function(){
        if (botContent.style.display === "none") {
            botContent.style.display = "block"; // Show the chat container
        } else {
            botContent.style.display = "none"; // Hide the chat container
        }
    })
    openDisclaimer.addEventListener("click",function(){
        if (textContent.style.display === "none") {
            textContent.style.display = "block"; // Show the chat container
        } else {
            textContent.style.display = "none"; // Hide the chat container
        }
    })
});


